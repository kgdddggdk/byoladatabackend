// server.js
// B Yola Data backend — keeps all secret keys server-side.
//
// Run locally:
//   1. npm install
//   2. cp .env.example .env   (then fill in your real VTpass/OPay keys)
//   3. npm start
//
// The frontend app should call THIS server (e.g. https://your-backend.onrender.com)
// instead of holding any secret keys itself.

require("dotenv").config();
const express = require("express");
const cors = require("cors");
const vtpass = require("./vtpassClient");
const wallet = require("./walletStore");

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;

// ---------------------------------------------------------------------------
// Health check
// ---------------------------------------------------------------------------
app.get("/", (req, res) => {
  res.json({ ok: true, service: "B Yola Data backend", env: process.env.VTPASS_ENV });
});

// ---------------------------------------------------------------------------
// Catalog endpoints — the frontend calls these to show live plans/prices
// instead of hard-coded ones.
// ---------------------------------------------------------------------------

// GET /api/plans/:serviceID   e.g. /api/plans/mtn-data
app.get("/api/plans/:serviceID", async (req, res) => {
  try {
    const data = await vtpass.getVariations(req.params.serviceID);
    res.json(data);
  } catch (err) {
    console.error(err.response?.data || err.message);
    res.status(500).json({ error: "Could not fetch plans from VTpass" });
  }
});

// GET /api/vtpass-balance — check your own VTpass float (not a customer's wallet)
app.get("/api/vtpass-balance", async (req, res) => {
  try {
    const data = await vtpass.getWalletBalance();
    res.json(data);
  } catch (err) {
    console.error(err.response?.data || err.message);
    res.status(500).json({ error: "Could not fetch VTpass balance" });
  }
});

// ---------------------------------------------------------------------------
// Customer wallet endpoints
// ---------------------------------------------------------------------------

app.get("/api/wallet/:customerId", (req, res) => {
  res.json({ balance: wallet.getBalance(req.params.customerId) });
});

app.get("/api/transactions/:customerId", (req, res) => {
  res.json({ transactions: wallet.listTransactions(req.params.customerId) });
});

// ---------------------------------------------------------------------------
// Wallet funding — creates a PENDING request. It is only ever moved to
// SUCCESS by the OPay webhook below (never by the frontend directly).
// ---------------------------------------------------------------------------
app.post("/api/wallet/fund/initiate", (req, res) => {
  const { customerId, amount, reference } = req.body;
  if (!customerId || !amount || !reference) {
    return res.status(400).json({ error: "customerId, amount and reference are required" });
  }
  wallet.createFundingRequest(reference, customerId, amount);
  res.json({ status: "PENDING", reference });
});

// ---------------------------------------------------------------------------
// OPay webhook — OPay calls THIS endpoint when a transfer to your account
// (9163556157 / B YOLA SUD) is confirmed. Configure this URL in your OPay
// merchant dashboard as the webhook/callback URL.
//
// This is a STARTING POINT — before going live you must:
//   1. Verify the request really came from OPay (signature check using
//      OPAY_WEBHOOK_SECRET — see OPay's webhook signature docs for the
//      exact algorithm, since it can change between API versions).
//   2. Match the amount and reference against what you stored in
//      createFundingRequest, and never trust the amount blindly.
// ---------------------------------------------------------------------------
app.post("/api/webhooks/opay", async (req, res) => {
  try {
    // TODO: verify signature header against OPAY_WEBHOOK_SECRET before trusting this payload.
    const { reference, amount, status } = req.body; // adjust field names to match OPay's real payload

    const fundingReq = wallet.getFundingRequest(reference);
    if (!fundingReq) {
      console.warn("Webhook for unknown reference:", reference);
      return res.status(404).json({ error: "Unknown reference" });
    }

    if (fundingReq.status !== "PENDING") {
      return res.json({ ok: true, note: "Already processed" });
    }

    if (status === "SUCCESS" && Number(amount) === Number(fundingReq.amount)) {
      wallet.markFundingStatus(reference, "SUCCESS");
      wallet.credit(fundingReq.customerId, fundingReq.amount);
      wallet.logTransaction({
        customerId: fundingReq.customerId,
        type: "Wallet funding",
        detail: "OPay transfer verified",
        amount: fundingReq.amount,
        ref: reference,
        status: "SUCCESS",
      });
    } else {
      wallet.markFundingStatus(reference, "FAILED");
      wallet.logTransaction({
        customerId: fundingReq.customerId,
        type: "Wallet funding",
        detail: "OPay transfer failed or amount mismatch",
        amount: fundingReq.amount,
        ref: reference,
        status: "FAILED",
      });
    }

    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Webhook processing failed" });
  }
});

// ---------------------------------------------------------------------------
// Purchases — debit the customer's in-app wallet, then call VTpass.
// If VTpass fails, the debit is rolled back.
// ---------------------------------------------------------------------------

// POST /api/buy  { customerId, type: "Data"|"Airtime"|"Electricity"|"Cable TV"|"Education",
//                  serviceID, amount, phone, billersCode, variation_code, ... }
app.post("/api/buy", async (req, res) => {
  const { customerId, type, amount, serviceID } = req.body;
  if (!customerId || !type || !amount || !serviceID) {
    return res.status(400).json({ error: "customerId, type, amount and serviceID are required" });
  }

  const balanceBefore = wallet.getBalance(customerId);
  if (balanceBefore < amount) {
    return res.status(400).json({ error: "Insufficient wallet balance" });
  }

  // Debit first so a customer can't fire two requests and spend the same money twice.
  wallet.debit(customerId, amount);

  try {
    const result = await vtpass.purchase(req.body);

    const success = result.code === "000";
    wallet.logTransaction({
      customerId,
      type,
      detail: result.response_description || serviceID,
      amount,
      ref: result.requestId || vtpass.generateRequestId(),
      status: success ? "SUCCESS" : "FAILED",
    });

    if (!success) {
      wallet.credit(customerId, amount); // refund on failure
    }

    res.json(result);
  } catch (err) {
    console.error(err.response?.data || err.message);
    wallet.credit(customerId, amount); // refund — VTpass call itself failed
    wallet.logTransaction({
      customerId,
      type,
      detail: "VTpass request failed",
      amount,
      ref: vtpass.generateRequestId(),
      status: "FAILED",
    });
    res.status(500).json({ error: "Purchase failed, wallet refunded" });
  }
});

app.listen(PORT, () => {
  console.log(`B Yola Data backend running on port ${PORT} (VTpass env: ${process.env.VTPASS_ENV})`);
});
