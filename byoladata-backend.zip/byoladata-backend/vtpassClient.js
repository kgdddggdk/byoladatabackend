// vtpassClient.js
// Small wrapper around the VTpass REST API.
// Docs: https://vtpass.com/documentation/
//
// IMPORTANT: this file reads secrets from process.env (set in your .env file
// or your hosting provider's "Environment Variables" settings) — they are
// NEVER hard-coded here and NEVER sent to the browser.

const axios = require("axios");

const BASE_URL =
  process.env.VTPASS_ENV === "live"
    ? process.env.VTPASS_LIVE_BASE_URL
    : process.env.VTPASS_SANDBOX_BASE_URL;

const API_KEY = process.env.VTPASS_API_KEY;
const PUBLIC_KEY = process.env.VTPASS_PUBLIC_KEY;
const SECRET_KEY = process.env.VTPASS_SECRET_KEY;

if (!API_KEY || !PUBLIC_KEY || !SECRET_KEY) {
  console.warn(
    "[vtpassClient] Missing VTpass keys in environment variables — set VTPASS_API_KEY, VTPASS_PUBLIC_KEY and VTPASS_SECRET_KEY in your .env file."
  );
}

// VTpass requires a unique request_id per purchase:
// first 12 characters must be numeric and be today's date+time (Africa/Lagos, GMT+1),
// e.g. "202601161830" + random suffix.
function generateRequestId() {
  const now = new Date(Date.now() + 60 * 60 * 1000); // shift to GMT+1
  const pad = (n) => String(n).padStart(2, "0");
  const stamp =
    now.getUTCFullYear().toString() +
    pad(now.getUTCMonth() + 1) +
    pad(now.getUTCDate()) +
    pad(now.getUTCHours()) +
    pad(now.getUTCMinutes());
  const suffix = Math.random().toString(36).slice(2, 10);
  return `${stamp}${suffix}`;
}

function getHeaders(method) {
  if (method === "GET") {
    return { "api-key": API_KEY, "public-key": PUBLIC_KEY };
  }
  return { "api-key": API_KEY, "secret-key": SECRET_KEY };
}

async function vtpassGet(path, params = {}) {
  const res = await axios.get(`${BASE_URL}${path}`, {
    headers: getHeaders("GET"),
    params,
  });
  return res.data;
}

async function vtpassPost(path, body = {}) {
  const res = await axios.post(`${BASE_URL}${path}`, body, {
    headers: getHeaders("POST"),
  });
  return res.data;
}

// Get all service categories (data, airtime, tv-subscription, electricity-bill, education...)
function getServiceCategories() {
  return vtpassGet("/service-categories");
}

// Get services under a category, e.g. identifier=data
function getServicesByCategory(identifier) {
  return vtpassGet("/services", { identifier });
}

// Get variation codes (data plans / cable packages) for a serviceID, e.g. "mtn-data"
function getVariations(serviceID) {
  return vtpassGet("/service-variations", { serviceID });
}

// Check your VTpass wallet balance (the balance VTpass owes to fulfil orders)
function getWalletBalance() {
  return vtpassGet("/balance");
}

// Generic purchase call — works for airtime, data, electricity, cable, education
// once you pass the right serviceID + fields for that product.
function purchase(payload) {
  const body = { request_id: generateRequestId(), ...payload };
  return vtpassPost("/pay", body);
}

// Requery a transaction by request_id (use this if a purchase call times out —
// never assume failure just because the HTTP request failed; always requery).
function requeryTransaction(request_id) {
  return vtpassPost("/requery", { request_id });
}

module.exports = {
  generateRequestId,
  getServiceCategories,
  getServicesByCategory,
  getVariations,
  getWalletBalance,
  purchase,
  requeryTransaction,
};
