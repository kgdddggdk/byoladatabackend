# B Yola Data — backend (VTpass integration)

This is the missing piece for your B Yola Data app: a small server that
holds your VTpass API key safely and does the actual data/airtime/
electricity/cable purchases. Your app's frontend should never hold this
key — it must always go through this server.

## Step 1 — Get your VTpass keys

1. Create an account at https://vtpass.com (and a free sandbox account at
   https://sandbox.vtpass.com to test without spending real money).
2. On your VTpass dashboard, go to **API Keys**.
3. Set **API Authentication Type** to "all" or "API keys".
4. Copy your **API Key**, then click to generate your **Public Key** and
   **Secret Key** — these are shown only once, so save them somewhere safe
   immediately (e.g. a password manager).

## Step 2 — Run the backend on your computer

You need [Node.js](https://nodejs.org) installed (version 18 or newer).

```bash
cd byoladata-backend
npm install
cp .env.example .env
```

Open `.env` in a text editor and fill in:
- `VTPASS_API_KEY`, `VTPASS_PUBLIC_KEY`, `VTPASS_SECRET_KEY` — from Step 1
- Leave `VTPASS_ENV=sandbox` while testing

Then start it:

```bash
npm start
```

You should see: `B Yola Data backend running on port 4000 (VTpass env: sandbox)`

Visit `http://localhost:4000` in a browser — you should see a small JSON
health-check response confirming it's running.

## Step 3 — Test a purchase (sandbox)

VTpass's sandbox lets you simulate success/failure using specific test
phone numbers (listed in their docs per network). Example request once
your server is running:

```bash
curl -X POST http://localhost:4000/api/buy \
  -H "Content-Type: application/json" \
  -d '{
    "customerId": "test-user-1",
    "type": "Airtime",
    "serviceID": "mtn",
    "amount": 100,
    "phone": "08011111111"
  }'
```

(Note: a new wallet starts at ₦0 in this demo backend — credit it first
via `/api/wallet/fund/initiate` and the webhook, or temporarily edit
`walletStore.js` to seed a test balance.)

## Step 4 — Put your app online (deploy the backend)

Pick a host with a **free tier** while you're starting out:
- **Render.com** — free web service tier, connect your GitHub repo, add
  your `.env` values under "Environment" in their dashboard (never upload
  the `.env` file itself)
- **Railway.app** — similar free-tier flow
- A cheap VPS (Contabo, Hostinger) if you outgrow the free tiers

Whichever you choose, the steps are the same:
1. Push this folder to a GitHub repository (add a `.gitignore` with `.env`
   and `node_modules` in it so you never leak your keys)
2. Connect the repo to the hosting service
3. Add each variable from `.env.example` into the host's **Environment
   Variables** settings, with your real values
4. Deploy — you'll get a URL like `https://byoladata-backend.onrender.com`

## Step 5 — Connect your OPay webhook

1. In your OPay merchant dashboard, find the webhook/callback URL setting
2. Set it to: `https://YOUR-BACKEND-URL/api/webhooks/opay`
3. This lets OPay tell your server automatically when a transfer to
   **9163556157 (B YOLA SUD)** succeeds, so the customer's wallet is
   credited without you clicking anything manually
4. Before going live, finish the `TODO` in `server.js` that verifies the
   webhook signature — this stops anyone else from calling that URL and
   pretending a payment succeeded

## Step 6 — Point your frontend app at this backend

In your B Yola Data app, replace the parts that currently fake a purchase
or fake wallet funding with real calls to your backend URL, e.g.:

```js
fetch("https://YOUR-BACKEND-URL/api/buy", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ customerId, type: "Data", serviceID: "mtn-data", amount, phone, variation_code })
})
```

Send me your backend URL once it's deployed and I'll wire the app's
buttons to call it.

## Important notes

- `walletStore.js` currently stores everything in memory — restarting the
  server wipes all balances and history. Before real customers use this,
  swap it for a real database (Postgres is a solid default). Ask me and
  I can help with that next.
- Go live only after testing thoroughly in VTpass sandbox mode.
- Never commit your real `.env` file to GitHub, and never paste your real
  keys into the frontend HTML file.
