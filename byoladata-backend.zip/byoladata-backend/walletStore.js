// walletStore.js
//
// PLACEHOLDER wallet storage, kept in memory so this project runs out of the
// box with no database setup. Restarting the server erases all balances.
//
// Before going live, swap this file's contents for real database calls
// (Postgres, MySQL, MongoDB, etc.) — keep the same function names so
// nothing else in the project needs to change.

const wallets = new Map(); // customerId -> balance in Naira
const fundingRequests = new Map(); // reference -> { customerId, amount, status }
const transactions = []; // { id, customerId, type, detail, amount, ref, status, date }

function getBalance(customerId) {
  return wallets.get(customerId) || 0;
}

function credit(customerId, amount) {
  const bal = getBalance(customerId) + amount;
  wallets.set(customerId, bal);
  return bal;
}

function debit(customerId, amount) {
  const bal = getBalance(customerId);
  if (bal < amount) throw new Error("Insufficient wallet balance");
  wallets.set(customerId, bal - amount);
  return bal - amount;
}

function createFundingRequest(reference, customerId, amount) {
  fundingRequests.set(reference, { customerId, amount, status: "PENDING" });
}

function getFundingRequest(reference) {
  return fundingRequests.get(reference);
}

function markFundingStatus(reference, status) {
  const f = fundingRequests.get(reference);
  if (f) f.status = status;
  return f;
}

function logTransaction(entry) {
  transactions.push({ id: `TXN-${Date.now()}`, date: Date.now(), ...entry });
}

function listTransactions(customerId) {
  return transactions.filter((t) => !customerId || t.customerId === customerId);
}

module.exports = {
  getBalance,
  credit,
  debit,
  createFundingRequest,
  getFundingRequest,
  markFundingStatus,
  logTransaction,
  listTransactions,
};
